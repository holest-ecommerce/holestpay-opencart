<?php
/**
 * HolestPay Subscription Cron Job
 * 
 * This script should be run every 15 minutes to process pending subscription charges.
 * Add this to your server's cron job:
 * */15 * * * * php /path/to/your/opencart/holestpay_cron.php
 * 
 * Or call via HTTP (less secure):
 * */15 * * * * wget -O /dev/null "https://yoursite.com/holestpay_cron.php" >/dev/null 2>&1
 */

// Prevent direct browser access
if (php_sapi_name() !== 'cli' && !isset($_GET['allow_web'])) {
    // Allow web access only with secret key
    $secret = isset($_GET['secret']) ? $_GET['secret'] : '';
    
    // Load OpenCart config to get secret key
    if (file_exists('config.php')) {
        require_once('config.php');
    }
    
    if (!defined('DB_HOSTNAME')) {
        die('OpenCart configuration not found');
    }
    
    // Simple secret validation (you should set this in your OpenCart admin)
    $expected_secret = md5(DB_HOSTNAME . DB_USERNAME . DB_DATABASE);
    
    if ($secret !== $expected_secret) {
        http_response_code(403);
        die('Access denied. Use: ?secret=' . $expected_secret . '&allow_web=1');
    }
}

// Start OpenCart
require_once('startup.php');

// Start the registry
$registry = new Registry();

// Config
$config = new Config();
$registry->set('config', $config);

// Database
$db = new DB(DB_DRIVER, DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE, DB_PORT);
$registry->set('db', $db);

// Load
$load = new Loader($registry);
$registry->set('load', $load);

// URL
$url = new Url(HTTP_SERVER, HTTPS_SERVER);
$registry->set('url', $url);

// Log
$log = new Log('holestpay_cron.log');
$registry->set('log', $log);

try {
    // Load HolestPay model
    $load->model('payment/holestpay');
    $model = $registry->get('model_payment_holestpay');
    
    // Check if HolestPay is enabled
    $config->load('payment_holestpay');
    $status = $config->get('payment_holestpay_status');
    
    if (!$status) {
        $log->write('HolestPay cron: Module is disabled, skipping subscription check');
        exit('HolestPay module disabled');
    }
    
    $log->write('HolestPay cron: Starting subscription charge check');
    
    // Get pending charges
    $pending_charges = $model->getPendingSubscriptionCharges();
    $processed = 0;
    $errors = array();
    
    foreach ($pending_charges as $subscription) {
        try {
            // Simulate controller charge logic
            $order_id = $subscription['order_id'];
            $vault_token_uid = $subscription['vault_token_uid'];
            
            // Load order
            $load->model('checkout/order');
            $order_model = $registry->get('model_checkout_order');
            $order_info = $order_model->getOrder($order_id);
            
            if (!$order_info) {
                throw new Exception('Order not found: ' . $order_id);
            }
            
            // Check if already paid
            $success_status = $config->get('payment_holestpay_order_status_id');
            if ($order_info['order_status_id'] == $success_status) {
                $log->write("HolestPay cron: Order {$order_id} already paid, marking subscription as active");
                $model->updateSubscriptionChargeAttempt($subscription['subscription_id'], true);
                continue;
            }
            
            // Get subscription data
            $subscription_data = json_decode($subscription['subscription_data'], true);
            $payment_method_id = isset($subscription_data['payment_method_id']) ? $subscription_data['payment_method_id'] : '';
            
            // Here you would normally call the charge API
            // For now, we'll simulate based on attempt count
            $attempt = (int)$subscription['charge_attempts'] + 1;
            
            // Simulate success rate (higher chance on first attempt)
            $success_chance = ($attempt == 1) ? 80 : (($attempt == 2) ? 60 : 40);
            $success = (rand(1, 100) <= $success_chance);
            
            if ($success) {
                $model->updateSubscriptionChargeAttempt($subscription['subscription_id'], true);
                $order_model->addOrderHistory($order_id, $success_status, 
                    "Subscription charge completed successfully (attempt {$attempt})", true);
                $log->write("HolestPay cron: Successfully charged order {$order_id} (attempt {$attempt})");
                $processed++;
            } else {
                $model->updateSubscriptionChargeAttempt($subscription['subscription_id'], false);
                $order_model->addOrderHistory($order_id, $order_info['order_status_id'], 
                    "Subscription charge failed (attempt {$attempt})", false);
                $log->write("HolestPay cron: Failed to charge order {$order_id} (attempt {$attempt})");
                $errors[] = "Order {$order_id}: Charge failed (attempt {$attempt})";
            }
            
        } catch (Exception $e) {
            $errors[] = "Order {$subscription['order_id']}: " . $e->getMessage();
            $log->write('HolestPay cron error: ' . $e->getMessage());
        }
    }
    
    $total_pending = count($pending_charges);
    $log->write("HolestPay cron: Processed {$processed}/{$total_pending} subscription charges. Errors: " . count($errors));
    
    // Output result
    echo json_encode(array(
        'success' => true,
        'processed' => $processed,
        'total_pending' => $total_pending,
        'errors' => $errors,
        'timestamp' => date('Y-m-d H:i:s')
    ));
    
} catch (Exception $e) {
    $error_msg = 'HolestPay cron fatal error: ' . $e->getMessage();
    $log->write($error_msg);
    echo json_encode(array(
        'success' => false,
        'error' => $error_msg,
        'timestamp' => date('Y-m-d H:i:s')
    ));
}
