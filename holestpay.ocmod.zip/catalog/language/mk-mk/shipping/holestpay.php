<?php
// Text
$_['text_title'] = 'HolestPay достава';
$_['text_description'] = 'HolestPay испорака';
$_['text_weight'] = 'Тежина:';
$_['text_eta'] = 'Проценето време на испорака:';
$_['text_pickup'] = 'Лично преземање';
$_['text_cod'] = 'Плаќање на пошта';
$_['text_free_shipping'] = 'Бесплатна достава';
$_['text_express'] = 'Експресна достава';
$_['text_standard'] = 'Стандардна достава';
