<?php
// Text
$_['text_title'] = 'HolestPay достава';
$_['text_description'] = 'HolestPay испорука';
$_['text_weight'] = 'Тежина:';
$_['text_eta'] = 'Процењено време испоруке:';
$_['text_pickup'] = 'Лично преузимање';
$_['text_cod'] = 'Плаћање пошиљаоцу';
$_['text_free_shipping'] = 'Бесплатна достава';
$_['text_express'] = 'Експресна достава';
$_['text_standard'] = 'Стандардна достава';
