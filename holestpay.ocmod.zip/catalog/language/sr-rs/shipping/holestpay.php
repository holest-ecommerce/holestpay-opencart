<?php
// Text
$_['text_title'] = 'HolestPay dostava';
$_['text_description'] = 'HolestPay isporuka';
$_['text_weight'] = 'Težina:';
$_['text_eta'] = 'Procenjeno vreme isporuke:';
$_['text_pickup'] = 'Lično preuzimanje';
$_['text_cod'] = 'Plaćanje pošiljaocu';
$_['text_free_shipping'] = 'Besplatna dostava';
$_['text_express'] = 'Ekspresna dostava';
$_['text_standard'] = 'Standardna dostava';
