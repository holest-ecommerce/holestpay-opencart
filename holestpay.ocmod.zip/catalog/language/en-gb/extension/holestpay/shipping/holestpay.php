<?php
// Simply load the original language file
require_once __DIR__ . '/../../../shipping/holestpay.php';